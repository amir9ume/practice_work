import numpy as np

from problem1.activation_functions import softmax_stable
from network_model import *

# gradient of the loss function L, wrt to Theta 1:p
# m is the dimension of first layer weights of the MLP.







